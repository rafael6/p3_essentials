import sys

def main():
    print('Python version {}.{}.{}'.format(*sys.version_info))
    print('The category of the OS is: {}'.format(sys.platform))

    import os
    print('The OS type is: {}'.format(os.name))
    print('The path variable is: {}'.format(os.getenv('PATH')))
    print('Current working directory is: {}'.format(os.getcwd()))
    print('A 25 bytes long string: {}'.format(os.urandom(25)))

    import urllib.request
    page = urllib.request.urlopen('http://bw.org')
    print(page)
    #for line in page:
        #print(str(line, encoding='utf_8'), end='')

    import random
    print(random.randint(1, 1000)) # Inclusive

    l = [0, 1, 2, 3, 4, 5]
    print(l)
    random.shuffle(l) # Shufles the list
    print(l)

    import datetime
    now = datetime.datetime.now()
    print(now)
    print(now.year, now.month, now.day, now.hour, now.min, now.second)

if __name__ == "__main__": main()

